package com.tuling.mall.skywalkingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSkywalkingDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
